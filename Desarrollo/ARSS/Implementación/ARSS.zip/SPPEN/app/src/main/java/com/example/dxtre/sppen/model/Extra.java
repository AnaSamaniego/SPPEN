package com.example.dxtre.sppen.model;

/**
 * Created by DXtre on 19/11/16.
 */

public class Extra {

    private int idClientExtra;
    private String name;
    private int cost;
    private int time;
    private int count;

    public Extra(){

    }

    public Extra(int idClientExtra, String name, int cost, int time, int count) {
        this.idClientExtra = idClientExtra;
        this.name = name;
        this.cost = cost;
        this.time = time;
        this.count = count;
    }

    public int getIdClientExtra() {
        return idClientExtra;
    }

    public void setIdClientExtra(int idClientExtra) {
        this.idClientExtra = idClientExtra;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}