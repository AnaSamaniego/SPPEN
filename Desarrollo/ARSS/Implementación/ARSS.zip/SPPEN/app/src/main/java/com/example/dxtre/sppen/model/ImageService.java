package com.example.dxtre.sppen.model;

/**
 * Created by DXtre on 6/10/16.
 */

public class ImageService {

    private int id;
    private String photo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}