package com.example.dxtre.sppen.components.interfaces;

/**
 * Created by DXtre on 14/11/16.
 */

public interface OnExtra {

    void increase(int position);
    void decrease(int position);

}