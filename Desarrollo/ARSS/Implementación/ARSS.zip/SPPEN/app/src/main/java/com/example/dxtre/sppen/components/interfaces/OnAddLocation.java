package com.example.dxtre.sppen.components.interfaces;

import com.example.dxtre.sppen.model.LocationService;

/**
 * Created by DXtre on 8/12/16.
 */

public interface OnAddLocation {

    void addLocation(LocationService locationService);

}