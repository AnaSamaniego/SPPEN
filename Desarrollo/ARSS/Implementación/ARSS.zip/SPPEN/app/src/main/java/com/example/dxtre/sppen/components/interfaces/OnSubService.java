package com.example.dxtre.sppen.components.interfaces;

/**
 * Created by DXtre on 14/11/16.
 */

public interface OnSubService {

    void count(int position);
    void delete(int position);

}