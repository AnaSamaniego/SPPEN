package com.example.dxtre.sppen.util;

/**
 * Created by DXtre on 15/09/16.
 */

public class Constants {

    public static String woman = "femenino";
    public static String man = "masculino";

    public static  int maxServices = 5;

    public static int IMAGE_MAX_SIZE = 1024;

    public static int TIME_RELOAD_CHAT = 15000;

    public static int PERMISSIONS_APP_CODE=1;

}