package com.example.dxtre.sppen.model;

/**
 * Created by DXtre on 25/11/17.
 */

public class Promotion {

    private int idService;
    private int discount;

    public Promotion(int idService, int discount) {
        this.idService = idService;
        this.discount = discount;
    }

    public int getIdService() {
        return idService;
    }

    public void setIdService(int idService) {
        this.idService = idService;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }
}