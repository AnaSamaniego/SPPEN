package com.example.dxtre.glam;

import com.example.dxtre.sppen.util.ApiHelper;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * Created by DXtre on 18/11/17.
 */
@RunWith(MockitoJUnitRunner.class)
public class ConvertNumberUnitTest {

    @Test
    public void testConvertNumber() {
        //isValidEmail
        Assert.assertEquals(ApiHelper.parseString(4.25), "4.35");
    }

}