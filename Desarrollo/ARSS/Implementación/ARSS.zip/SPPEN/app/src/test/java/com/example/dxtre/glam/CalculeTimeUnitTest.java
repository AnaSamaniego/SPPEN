package com.example.dxtre.glam;

import com.example.dxtre.sppen.model.Extra;
import com.example.dxtre.sppen.model.InfoService;
import com.example.dxtre.sppen.model.SubService;
import com.example.dxtre.sppen.util.ApiHelper;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;

/**
 * Created by DXtre on 18/11/17.
 */

@RunWith(MockitoJUnitRunner.class)
public class CalculeTimeUnitTest {

    @Test
    public void testCalculePrice() {

        InfoService infoService = new InfoService();

        ArrayList<Extra> lstExtra = new ArrayList<>();

        lstExtra.add(new Extra(1, "name1", 2, 2, 2));
        lstExtra.add(new Extra(2, "name2", 2, 2, 2));

        infoService.setLstExtras(lstExtra);

        ArrayList<SubService> lstSubService = new ArrayList<>();

        lstSubService.add(new SubService(1, "subservice1",1,2,2));
        lstSubService.add(new SubService(2, "subservice2",1,2,2));

        infoService.setLstSubServices(lstSubService);

        Assert.assertEquals(ApiHelper.calculeTime(infoService), 12);
    }

}